"""
This module allows to normalize texts applying different normalizations.
"""

from __future__ import absolute_import

__version__ = '2.2.1'

from cucco.cucco import Cucco
